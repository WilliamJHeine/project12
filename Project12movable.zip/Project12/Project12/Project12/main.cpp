//345678901234567890123456789012345678901234567890123456789012345678901234567890
//  ****************************************************************************
//  *                                                                          *
//  *  Programmer(s): YourName                                                 *
//  *  Program:       Chapter16and17ExceptionsTemplatesLinkedList              *
//  *  Source cpp:    main.cpp                                                 *
//  *                 LinkedList.h                                             *
//  *  School:        St. Louis Community College                              *
//  *  Class:         IS 275 267 Advanced C++ Programming                      *
//  *  Instructor:    David Doering                                            *
//  *  Assigned Date: 01 January 2001                                          *
//  *  Due Date:      02 January 2001                                          *
//  *                                                                          *
//  *  New Concepts:  LinkedList, Templates                                    *
//  *                                                                          *
//  *                                                                          *
//  *  Purpose:       Program tracks sales of type cash and credit.            *
//  *                 Program records customer number and outputs total sales. *
//  *                                                                          *
//  *  Input:         User - Type of sale, dollar amount, && customer number   *
//  *                                                                          *
//  *  Processing:    DescribeInAFewSentencesTheMajorCalculations              *
//  *                 AndOtherProcessingProgramDoes                            *
//  *                                                                          *
//  *  Output:        DescribeTheInformationBeingOutputToScreenOrFile          *
//  *                                                                          *
//  *                                                                          *
//  *  Additional:    IncludeAdditionalThoughtsPseudocodeEtC                   *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  *                                                                          *
//  * Style Guide - Code: 80 columns, convert tabs to spaces, tab is 2 spaces, *
//  *               To be determined                                           *
//  *                                                                          *
//  * Style Guide - Print: 80 columns, 64 row title page, print line numbers,  *
//  *               header of full path file name and date printed,            *
//  *               footer of page number                                      *
//64****************************************************************************

//		**************************************************************************
//		*             Preprocessor Directive              	                     *
//		**************************************************************************

#include <iomanip>  	                      // setw and setprecision 
#include <iostream> 	                      // cin cout
#include "LinkedList.h"
#include "Error.h"

//		**************************************************************************
//		*             Standard Library		              	                       *
//		**************************************************************************

using namespace std;                        // OK for education, not real-life

											//		**************************************************************************
											//    *             Variable Initialization                                    *
											//		**************************************************************************

char Enter;                                 // for Press Enter to End

											//		**************************************************************************
											//    *             Class Customer                                             *
											//		**************************************************************************

class Customer;
template class LinkedList<Customer>;
template class Node<Customer>;
class Customer
{
public:
	Customer(LinkedList<Customer>* pList, unsigned accNo)
	{
		customerNumber = accNo;               // initialize the data members
		balance = 0;

		// add self to the list and count it
		// CORRECT ME   =  <>(, );   new Node Customer pList pNode this         // Dynamically allocate a new Node using the Customer template with two parameters
		pNode = new Node<Customer>(pList, this);///????
		pList->addNode(pNode);
		count++;
	}

	//  ********    access functions                                    ********
	int customerNo() { return customerNumber; }
	double acntBalance() { return balance; }
	static int noCustomers() { return count; }

	// CORRECT ME  * (<>* )    Customer Customer first LinkedList pLinkedList static          // 
	static Customer* first (LinkedList<Customer>* pLinkedList)///????
	{
		Node<Customer>* pNode = pLinkedList->firstNode();
		return pNode->current();
	}
	Customer* next()
	{
		// CORRECT ME  <>*  = ->();  Customer next  Node  pNextNode  pNode           // using Customer template develop a new Node for pNextNOde
		Node<Customer>* pNextNode = pNode->next();///???? #1
		return pNextNode->current(); //#1
	}

	//  ********    transaction functions                               ********
	void sale(double amount) { balance += amount; }
	virtual bool merchReturn(double amount)
	{
		balance -= amount;
		return true;
	}

	//  ********    display function to display each transaction        ********
	void display()
	{
		cout << "\n\t" << type()
			<< " customer " << customerNumber
			<< " = " << balance
			<< endl;
	}

	virtual const char* type() = 0;

protected:
	Node<Customer>* pNode;

	static int count;             // number of customers
	unsigned customerNumber;
	double   balance;
};

// allocate space for statics
int Customer::count = 0;

//		**************************************************************************
//    *             Class Credit                                               *
//		**************************************************************************

class Credit : public Customer
{
public:
	// CORRECT ME  (<>* ,  ): (, ) { } accNo accNo Credit LinkedList Customer Customer pLL pLL unsigned          
	Credit(LinkedList<Customer>* pLL, unsigned accNo): Customer(pLL, accNo) { }///????
	// overload pure virtual functions
	virtual bool merchReturn(double amount);
	virtual const char* type() { return "Credit"; }
};

//  ********    overload the Customer::merchReturn() member             ********
//  ********    to charge a $5 restocking fee on all credit returns     ********
bool Credit::merchReturn(double amount)
{
	// CORRECT ME   = :: (); amount bool  Customer merchReturn  success      // Create a bool variable called success that will run customers merchReturn overloaded function
	bool success = Customer::merchReturn(amount);///????

	balance += 5.00;
	cout << "\t$5 restocking fee for all credit returns\n";

	return success;
}

//		**************************************************************************
//    *             Class Cash                                                 *
//		**************************************************************************

class Cash : public Customer
{
public:

	// CORRECT ME (<>* , ) : (, ) accNo accNo Cash LinkedList Customer Customer pLL pLL unsigned  
	 Cash(LinkedList<Customer>* pLL, unsigned accNo):Customer(pLL, accNo)///????
{
	numReturns = 0;
}

// transaction functions
virtual bool merchReturn(double amount);
virtual const char* type()
{
	return "Cash";
}

protected:
	int numReturns;
};

//  ********    overload the Customer::merchReturn() member             ********
//  ********    function to charge a $2.00 fee after the first          ********
//  ********    merchandise return of the month                         ********

bool Cash::merchReturn(double amount)
{
	// CORRECT ME  (++ > )      1 if numReturns        // develop an if that check, within the parameters is an increment check of numReturn insuring that numReturn is greater than 1.  Else, return the amount
	if(++numReturns > 1)///????
	{
		balance += 2.00;
		cout << "\t$2 restocking fee (for 2nd and additional returns)\n";
	}
	// CORRECT ME ::();  amount Customer merchReturn return  
	return Customer::merchReturn(amount);///????
}

//		**************************************************************************
//    *             Function Prototypes	              	                       *
//		**************************************************************************

void displayHeader();                       // Display program header
void displayProgramDescription();           // Display program description
//void displayOutput();///????
unsigned getAccntNo();
void process(Customer* pCustomer);
// CORRECT ME ( < >*  );  Customer getCustomers LinkedList  pLinkedList void       // Develop a prototype called get customers that create a pointer for the link list Customer template.
void getCustomers(LinkedList<Customer>* pLinkedList);///????
void displayResults(LinkedList<Customer>* pLinkedList);
char CTInput();
double AmountInput();

//  ****************************************************************************
//  ****************************************************************************
//  ****            Main Function Directive                                 ****
//  ****************************************************************************
//  ****************************************************************************

int main(int argcs, char* pArgs[])
{
	displayHeader();
	displayProgramDescription();

	// create a link list to attach customers to
	LinkedList<Customer> linkedList;

	// read customers from user
	getCustomers(&linkedList);

	// display the linked list of customers
	displayResults(&linkedList);


	//  ********        End Program                                         ********
	cout << "\n\tPress Enter to exit the program..." << endl;
	cin.ignore(9999, '\n');
	cin.get();
	return 0;
}

//    **************************************************************************
//    *             function - getCustomers                                    *
//    **************************************************************************

// CORRECT ME ( < >*  )  Customer getCustomers LinkedList  pLinkedList void           // create a getCustomer function and within the parameters create a pointer for your linked list customer template.
void getCustomers(LinkedList<Customer>* pLinkedList)///????
{
	Customer* pA = NULL;
	// loop until someone enters 'X' or 'x'
	char   customerType;     // S or C
	while (true)
	{
		customerType = CTInput();

		switch (customerType)
		{
		case 'c':
		case 'C':
			cout << "\n\tCredit - ";
			// CORRECT ME   =    ( ,  ()); Credit getAccntNo  new pA  pLinkedList              // dynamic allocation for a Credit function. Within the parameters is a pointer to your linked list that runs getAccntNo with an empty parameter.  
			pA = new Credit(pLinkedList, getAccntNo());///????
			break;

		case 's':
		case 'S':
			cout << "\n\tCash - ";
			// CORRECT ME    =   ( ,  ()); Cash getAccntNo new  pA   pLinkedList              // dynamic allocation for a Cash function. Within the parameters is a pointer to your linked list that runs getAccntNo with an empty parameter.  
			pA = new Cash(pLinkedList, getAccntNo());///????
			break;

		case 'x':
		case 'X':
			return;

		default:
			cout << "\n\tIncorrect Entry. Please try again.\n";
		}

		// process the object we just created
		process(pA);
	}
}

//    **************************************************************************
//    *             function - getAccntNo                                      *
//    **************************************************************************

unsigned getAccntNo()
{
	Error burrito;
	unsigned accntNo;

	///
	try
	{
		cout << "\n\tEnter customer number:";
		accntNo = burrito.getInputCNum();                //  ADD EXCEPTION HANDLING
	}
	catch (Error::OutOfRange)
	{
		cout << setw(5) << " " << "ERROR: improper customer number data detected\n";
		accntNo = getAccntNo();
	}
	return accntNo;

}

//    **************************************************************************
//    *             function - process                                         *
//    **************************************************************************

void process(Customer* pCustomer)
{
	cout << "\n\tEnter a positive number for a merchandise sale,\n"
		<< "\tnegative number for a merchandise return,"
		<< "or 0 (zero) to stop\n";
	double transaction;
	while (true)
	{
		transaction = AmountInput();                 // ADD EXCEPTION HANDLING
		if (transaction == 0)
		{
			break;
		}
		// sale
		if (transaction > 0)
		{
			// CORRECT ME -> ( );  pCustomer sale transaction
			pCustomer->sale(transaction);///????
		}
		// merchandise return
		if (transaction < 0)
		{
			// CORRECT ME -> (- );   merchReturn  pCustomer  transaction
			pCustomer->merchReturn(-transaction);///????
		}
	}
}

//    **************************************************************************
//    *             displayResults                                             *
//    **************************************************************************

void displayResults(LinkedList<Customer>* pLinkedList)
{
	// present totals
	double total = 0.0;
	cout << "\n\tCustomer totals:\n";
	// CORRECT ME ( < >*   =  -> (); != 0;  = ->())  firstNode for Node Customer pLinkedList pN pN  0 pN  pN next  
	for (Node<Customer>* pN = pLinkedList->firstNode(); pN != 0; pN = pN->next())///???? 11
	{
		Customer* pA = pN->current();
		pA->display();
		total += pA->acntBalance();
	}
	cout << "\n\tTotal Net Sales = " << total << "\n";
}
//    **************************************************************************
//    *             displayHeader	              	                             *
//    **************************************************************************

void displayHeader()
{
	cout << "\n";
	cout << setw(13) << " ";
	cout << "Chapters 16 and 17 Exceptions, Templates, and Linked Lists\n";
	cout << setw(27) << " " << "by William J. Heine \n";
	cout << setw(29) << " " << "April 18, 2018 \n\n";
}

//    **************************************************************************
//    *             displayProgramDescription	                                 *
//    **************************************************************************

void displayProgramDescription()
{
	cout << "\tThis programs uses exceptions, templates, and Linked Lists.\n";
	cout << "\tThis program accepts sales data from the user and outputs\n";
	cout << "\tthe list and provides a total.\n\n\n";

}

char CTInput()
{
	Error taco;
	char input = ' ';

	try
	{
		cout << "\n\tEnter S for Cash, "
			<< "C for Credit, X to exit program:";
		input = taco.getInputChar();                //  ADD EXCEPTION HANDLING
	}
	catch (Error::OutOfRange)
	{
		cout << setw(5) << " " << "ERROR: improper character data detected\n";
		input = CTInput();
	}
	return input;
}

double AmountInput()
{
	Error churro;
	double input = 0.0;

	try
	{
		cout << "\tamount: ";
		input = churro.getInputD();                //  ADD EXCEPTION HANDLING
	}
	catch (Error::OutOfRange)
	{
		cout << setw(5) << " " << "ERROR: improper character data detected\n";
		input = AmountInput();
	}
	return input;
}