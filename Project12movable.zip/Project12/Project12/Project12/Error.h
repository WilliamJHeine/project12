#pragma once
#ifndef Error_H
#define Error_H

#include <iostream>
#include <iomanip>
//#include <string>

using namespace std;

class Error
{
private:
	char holderC;
	int holderI;
	double holderD;
public:
	class OutOfRange {};

	Error::Error() {};
	Error(char input)
	{
		holderC = input;
	}
	~Error() {};
	char getInputChar()
	{
		cin >> holderC;
		if (holderC == 'c' || holderC == 'C' || holderC == 's' || holderC == 'S' || holderC == 'x' || holderC == 'X')
		{
			return holderC;
		}
		else
		{
			throw OutOfRange();
		}
	}
	unsigned getInputCNum()
	{
		cin >> holderI;
		if (holderI > 0)
		{
			return holderI;
		}
		else
		{
			throw OutOfRange();
		}
	}
	double getInputD()
	{
		cin >> holderD;
		if (holderD  >= 0 || holderD < 0)
		{
			return holderD;
		}
		else
		{
			throw OutOfRange();
		}
	}
};

#endif Error_H;